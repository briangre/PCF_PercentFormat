var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad=function(t){var e={};function n(r){if(e[r])return e[r].exports;var u=e[r]={i:r,l:!1,exports:{}};return t[r].call(u.exports,u,u.exports,n),u.l=!0,u.exports}return n.m=t,n.c=e,n.d=function(t,e,r){n.o(t,e)||Object.defineProperty(t,e,{enumerable:!0,get:r})},n.r=function(t){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(t,"__esModule",{value:!0})},n.t=function(t,e){if(1&e&&(t=n(t)),8&e)return t;if(4&e&&"object"==typeof t&&t&&t.__esModule)return t;var r=Object.create(null);if(n.r(r),Object.defineProperty(r,"default",{enumerable:!0,value:t}),2&e&&"string"!=typeof t)for(var u in t)n.d(r,u,function(e){return t[e]}.bind(null,u));return r},n.n=function(t){var e=t&&t.__esModule?function(){return t.default}:function(){return t};return n.d(e,"a",e),e},n.o=function(t,e){return Object.prototype.hasOwnProperty.call(t,e)},n.p="",n(n.s=0)}([
/*!********************************!*\
  !*** ./PercentFormat/index.ts ***!
  \********************************/
/*! no static exports found */
/*! all exports used */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */function(t,e,n){"use strict";Object.defineProperty(e,"__esModule",{value:!0});var r=function(){function t(){}return t.prototype.init=function(t,e,n,r){this._container=r,this._context=t,this._notifyOutputChanged=e,this._output=document.createElement("input"),this._output.id="value",this._output.onblur=this.valueOnBlur.bind(this),this._container.appendChild(this._output),this._container.appendChild(document.createTextNode("%"))},t.prototype.valueOnBlur=function(){this._value=Number(this._output.value),this._notifyOutputChanged()},t.prototype.updateView=function(t){this._context=t,this._value=this._context.parameters.valueToFormat.raw;var e="Yes"==this._context.parameters.useActual.raw?this._value.toString():(100*this._value).toString();this._output.value=e},t.prototype.getOutputs=function(){return{valueToFormat:this._context.parameters.useActual.raw?this._value:this._value/100}},t.prototype.destroy=function(){},t}();e.PercentFormat=r}]);
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Sample.PercentFormat', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PercentFormat);
} else {
	var Sample = Sample || {};
	Sample.PercentFormat = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.PercentFormat;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}